//
//  DetailsViewController.h
//  Tarea1.2
//
//  Created by David on 7/5/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Historial.h"

@interface DetailsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *marcalabel;
@property (weak, nonatomic) IBOutlet UILabel *modelolabel;
@property (weak, nonatomic) IBOutlet UILabel *clientelabel;
@property (weak, nonatomic) IBOutlet UILabel *detalleslabel;
@property (weak, nonatomic) IBOutlet UILabel *montolabel;

@property (nonatomic, strong) Historial* info;


@end
