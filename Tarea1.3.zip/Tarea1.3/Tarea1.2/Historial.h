//
//  Historial.h
//  Tarea1.2
//
//  Created by David on 7/4/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Realm/Realm.h>

@interface Historial : RLMObject

@property NSString *marca;
@property NSString *modelo;
@property NSString *cliente;
@property NSString *detalles;
@property NSString *monto;
@property NSDate *dates;

@end

RLM_ARRAY_TYPE(Historial);