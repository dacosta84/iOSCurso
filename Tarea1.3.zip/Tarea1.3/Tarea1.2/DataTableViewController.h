//
//  DataTableViewController.h
//  Tarea1.2
//
//  Created by David on 7/4/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Realm/Realm.h>
#import "Datos.h"

@interface DataTableViewController : UITableViewController

@property (nonatomic, strong) RLMResults *informacion;
@property (nonatomic, strong) Datos *getinformation;

@end
