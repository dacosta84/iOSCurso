//
//  DetailsViewController.m
//  Tarea1.2
//
//  Created by David on 7/5/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "DetailsViewController.h"

@interface DetailsViewController ()

@end

@implementation DetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialize];
    // Do any additional setup after loading the view.
}

-(void)initialize{
    self.marcalabel.text = self.info.marca;
    self.modelolabel.text = self.info.modelo;
    self.clientelabel.text = self.info.cliente;
    self.detalleslabel.text = self.info.detalles;
    self.montolabel.text = self.info.monto;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
