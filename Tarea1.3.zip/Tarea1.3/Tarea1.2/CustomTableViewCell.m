//
//  CustomTableViewCell.m
//  Tarea1.2
//
//  Created by David on 7/5/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "CustomTableViewCell.h"

@implementation CustomTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
