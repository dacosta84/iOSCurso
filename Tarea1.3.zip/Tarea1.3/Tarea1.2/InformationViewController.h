//
//  InformationViewController.h
//  Tarea1.2
//
//  Created by David on 7/4/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Historial.h"
#import "Datos.h"

@interface InformationViewController : UIViewController <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *marcatext;
@property (weak, nonatomic) IBOutlet UITextField *modelotext;
@property (weak, nonatomic) IBOutlet UITextField *clientetext;
@property (weak, nonatomic) IBOutlet UITextField *detallestextview;

@property (weak, nonatomic) IBOutlet UITextField *montotext;

@property (nonatomic, strong)Historial *informacion;
@property (nonatomic, strong)Datos *getinfo;


@end
