//
//  DataTableViewController.m
//  Tarea1.2
//
//  Created by David on 7/4/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "DataTableViewController.h"
#import "Historial.h"
#import "InformationViewController.h"
#import "DetailsViewController.h"


static int NUMBER_SECTION = 1;
static NSString* CELL_IDENTIFIER = @"CELL_INFORMATION";

@interface DataTableViewController ()

@end

@implementation DataTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialize];

}

-(void)viewWillAppear:(BOOL)animated{
    self.informacion = [self.getinformation.historial sortedResultsUsingProperty:@"cliente" ascending:YES];
    [self.tableView reloadData];
}

-(void) initialize{
    UIBarButtonItem *addButton =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addinfo)];
    NSMutableArray* barArray =[NSMutableArray new];
    [barArray addObject:addButton];
    [barArray addObject:self.editButtonItem];
    self.navigationItem.rightBarButtonItems = barArray;
}

-(void) addinfo{
    InformationViewController * information =[self.storyboard instantiateViewControllerWithIdentifier:@"InformationViewController"];
    information.getinfo = self.getinformation;
    [self.navigationController pushViewController:information animated:YES];
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return NUMBER_SECTION;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.informacion count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER forIndexPath:indexPath];
    
    if(cell == nil){
        cell =[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CELL_IDENTIFIER];
    }
    
    Historial* object = [self.informacion objectAtIndex:indexPath.row];
    cell.textLabel.text = object.cliente;
    
    NSLocale* currentLocale = [NSLocale currentLocale];
    cell.detailTextLabel.text = [object.dates descriptionWithLocale:currentLocale];
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    Historial* selectedObject = [self.informacion objectAtIndex:indexPath.row];
    
    DetailsViewController* detailView =[self.storyboard instantiateViewControllerWithIdentifier:@"DetailsViewController"];
    detailView.info = selectedObject;
    [self.navigationController pushViewController:detailView animated:YES];
}


// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {

}



@end
