//
//  ServiciosTableViewController.h
//  Tarea1.2
//
//  Created by David on 7/5/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Realm/Realm.h>

@interface ServiciosTableViewController : UITableViewController

@property (nonatomic, strong) RLMResults *categoryArray;

@end
