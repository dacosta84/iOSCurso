//
//  Datos.h
//  Tarea1.2
//
//  Created by David on 7/4/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Realm/Realm.h>
#import "Historial.h"

@interface Datos : RLMObject

@property NSString *cliente;
//@property NSString *marca;
//@property NSString *modelo;
//@property NSString *monto;
@property RLMArray<Historial> *historial;

@end
