//
//  InformationViewController.m
//  Tarea1.2
//
//  Created by David on 7/4/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "InformationViewController.h"


@interface InformationViewController ()

@end

@implementation InformationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialize];
   
}

-(void) initialize{
    self.marcatext.delegate = self;
    self.modelotext.delegate = self;
    self.clientetext.delegate = self;
    self.detallestextview.delegate = self;
    self.montotext.delegate = self;
    self.informacion = [Historial new];
    
    
   // -(void) initialize{
        UIBarButtonItem *addButton =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addinformation)];
        NSMutableArray* barArray =[NSMutableArray new];
        [barArray addObject:addButton];
        [barArray addObject:self.editButtonItem];
        self.navigationItem.rightBarButtonItems = barArray;
    }  // UIBarButtonItem *addButton =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addinformation)];
    //self.navigationItem.rightBarButtonItem = addButton;
    
//}



-(void) addinformation{
    NSString* marcaString = [self.marcatext.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSString* modeloString = [self.modelotext.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
     NSString* clienteString = [self.clientetext.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
     NSString* montoString = [self.montotext.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSString* detallesString = [self.detallestextview.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if(marcaString.length ==0 ||modeloString ==0 ||clienteString.length ==0 ||montoString.length ==0 ||detallesString.length ==0){
        UIAlertView* alert = [[UIAlertView alloc]initWithTitle: @"Error"message:@"Hay espacios en blanco" delegate:nil cancelButtonTitle:@"Aceptar" otherButtonTitles:nil, nil];
        [alert show];
        
    }else{
        
        self.informacion.marca = self.marcatext.text;
        self.informacion.modelo = self.modelotext.text;
        self.informacion.cliente = self.clientetext.text;
        self.informacion.monto = self.montotext.text;
        self.informacion.detalles = self.detallestextview.text;
        self.informacion.dates = [NSDate date];
        
        
        RLMRealm *real = [RLMRealm defaultRealm];
        [real beginWriteTransaction];
        [real addObject:self.informacion];
        [self.getinfo.historial addObject:self.informacion];
        [real commitWriteTransaction];
        
        
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}



//-(void)loadDefaultCategories{
    //RLMResults *categoriesTemp = [Datos allObjects];
    //if (categoriesTemp.count>ZERO) {
        //        si existen categorias
      //  self.categoryArray = categoriesTemp;
    //}
    //else{
        //        debo cargar las categorias
  //      [self insertCategoryInArray];
//    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (IBAction)hideKeyboard:(id)sender {
    [self.view endEditing:YES];
}


// MÉTODO PARA OCULTAR TECLADO CUANDO SE DA RETURN
-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if(textField == self.montotext){
        [self animateTextField: textField up: YES];
    }
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if(textField == self.montotext){
        [self animateTextField: textField up: NO];
    }
}

- (void) animateTextField: (UITextField*) textField up: (BOOL) up
{
    const int movementDistance = 60;
    const float movementDuration = 0.3f;
    
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}



@end
