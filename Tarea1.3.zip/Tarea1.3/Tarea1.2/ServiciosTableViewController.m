//
//  ServiciosTableViewController.m
//  Tarea1.2
//
//  Created by David on 7/5/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "ServiciosTableViewController.h"
#import "Datos.h"
#import "DataTableViewController.h"
#import "CustomTableViewCell.h"
#import "InformationViewController.h"

static int NUMBER_SECTION =1;
static int ZERO =0;
static NSString* CELL_IDENTIFIER =@"CustomTableViewCell";

@interface ServiciosTableViewController ()

@end

@implementation ServiciosTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UINib *nib = [UINib nibWithNibName:CELL_IDENTIFIER bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:CELL_IDENTIFIER];
    [self loadDefaultCategories];
}

-(void)loadDefaultCategories{
    RLMResults *categoriesTemp = [Datos allObjects];
    if (categoriesTemp.count>ZERO) {
        self.categoryArray = categoriesTemp;
    }
    else{
        [self insertCategoryInArray];
    }
}


#pragma -mark DATABASE OPERATIONS

-(void)insertCategoryInArray{
    Datos *categoria1 = [Datos new];
    categoria1.cliente = @"Marca";
   // categoria1.marca = @"Marca";
    Datos *categoria2 = [Datos new];
    categoria2.cliente = @"Motor";
    Datos *categoria3 = [Datos new];
    categoria3.cliente= @"Sistema Electrico";
    Datos *categoria4 = [Datos new];
    categoria4.cliente = @"Sistema de Enfriamiento";
    [self saveInDataBase:categoria1];
    [self saveInDataBase:categoria2];
    [self saveInDataBase:categoria3];
    [self saveInDataBase: categoria4];
    [self loadDefaultCategories];
}

-(void)saveInDataBase:(RLMObject*)newObject{
    RLMRealm *real = [RLMRealm defaultRealm];
    [real beginWriteTransaction];
    [real addObject:newObject];
    [real commitWriteTransaction];
}

  - (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return NUMBER_SECTION;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
return [self.categoryArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER];
    Datos* object = [self.categoryArray objectAtIndex:indexPath.row];
    cell.numeracioncustomlabel.text = [NSString stringWithFormat:@"%d",(int)indexPath.row+1];
    cell.clientecustomlabel.text = object.cliente;
  //  cell.marcacustomlabel.text = object.marca;
    return cell;
}

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    Datos* selectedObject = [self.categoryArray objectAtIndex:indexPath.row];
    
    DataTableViewController* serviciosView =[self.storyboard instantiateViewControllerWithIdentifier:@"DataTableViewController"];
    serviciosView.getinformation = selectedObject;
    [self.navigationController pushViewController:serviciosView animated:YES];
}

@end
