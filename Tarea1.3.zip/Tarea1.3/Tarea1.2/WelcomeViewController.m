//
//  WelcomeViewController.m
//  Tarea1.2
//
//  Created by David on 7/4/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "WelcomeViewController.h"
#import "InformationViewController.h"
#import "ServiciosTableViewController.h"

@interface WelcomeViewController ()

@end

@implementation WelcomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)ingresarbutton:(id)sender {
    InformationViewController *newinformation = [self.storyboard instantiateViewControllerWithIdentifier:@"InformationViewController"];
    [self.navigationController pushViewController:newinformation animated:YES];
}

- (IBAction)historialbutton:(id)sender {
    ServiciosTableViewController *historial = [self.storyboard instantiateViewControllerWithIdentifier:@"ServiciosTableViewController"];
    [self.navigationController pushViewController:historial animated:YES];
}
@end
