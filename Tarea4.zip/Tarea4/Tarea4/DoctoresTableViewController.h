//
//  DoctoresTableViewController.h
//  Tarea4
//
//  Created by David on 7/29/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DoctoresTableViewController : UITableViewController{
    DoctoresTableViewController *doctoresTableViewController;
}

@property (strong, nonatomic) IBOutlet UITableView *doctorestableview;
@property (nonatomic, strong) NSMutableArray* DoctoresArray;

@end
