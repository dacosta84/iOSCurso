//
//  DoctoresTableViewController.m
//  Tarea4
//
//  Created by David on 7/29/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "DoctoresTableViewController.h"
#import <Parse/Parse.h>
#import "DoctoresCustomCell.h"
#import "DoctorInfoViewController.h"

static NSString *cellIdentifier = @"DoctoresCustomCell";

@interface DoctoresTableViewController ()

@end

@implementation DoctoresTableViewController
@synthesize doctorestableview;

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialize];
    [self RetrieveFromParse];
    
}

-(void) initialize{
    self.DoctoresArray = [NSMutableArray new];
    
    UINib *nib = [UINib nibWithNibName:cellIdentifier bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:cellIdentifier];
}

-(void) RetrieveFromParse{
    PFQuery *query = [PFQuery queryWithClassName:@"Doctores"];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error){
        
        //NSLog(@"%@", objects);
        if (!error) {
            
            [self.DoctoresArray addObjectsFromArray:objects];
            [doctorestableview reloadData];
        }
        
    }];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.DoctoresArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    DoctoresCustomCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    NSDictionary *tempobjects = [self.DoctoresArray objectAtIndex:indexPath.row];
    
    //NSLog(@" %@", tempobjects);
    
    cell.DoctorNameLabel.text = [tempobjects objectForKey:@"Nombre"];
    cell.DoctorImageView.image = [[UIImage alloc] initWithData:[[tempobjects objectForKey:@"Foto"]getData]];
    // Configure the cell...

    return cell;
}

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DoctorInfoViewController *doctorInfoViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DoctorInfoViewController"];
    
    
    NSDictionary *temp = [self.DoctoresArray objectAtIndex:indexPath.row];
    
    doctorInfoViewController.docData = temp;
    
    [self.navigationController pushViewController:doctorInfoViewController animated:YES];
    
}

@end
