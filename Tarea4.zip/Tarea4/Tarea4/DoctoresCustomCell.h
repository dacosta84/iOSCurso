//
//  DoctoresCustomCell.h
//  Tarea4
//
//  Created by David on 8/21/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DoctoresCustomCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *DoctorImageView;
@property (weak, nonatomic) IBOutlet UILabel *DoctorNameLabel;

@end
