//
//  LoginViewController.h
//  Tarea4
//
//  Created by David on 7/29/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *usertextfield;
@property (weak, nonatomic) IBOutlet UITextField *passwordtextfield;
- (IBAction)loginbutton:(id)sender;
- (IBAction)signinaction:(id)sender;
- (IBAction)forgotpasswordaction:(id)sender;




@end
