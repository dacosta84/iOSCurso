//
//  DoctorInfoViewController.m
//  Tarea4
//
//  Created by David on 7/29/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "DoctorInfoViewController.h"
#import <Parse/Parse.h>
#import "DoctoresTableViewController.h"

@interface DoctorInfoViewController ()

@end

@implementation DoctorInfoViewController
@synthesize docnamelabel, docnumberlabel, docemaillabel, docespeclabel, docimageview, docunilabel;

- (void)viewDidLoad {
    
    docnamelabel.text = [self.docData objectForKey:@"Nombre"];
    docnumberlabel.text = [self.docData objectForKey:@"Numero"];
    docespeclabel.text = [self.docData objectForKey:@"Especialidad"];
    docemaillabel.text = [self.docData objectForKey:@"Email"];
    docunilabel.text = [self.docData objectForKey:@"Universidad"];
    docimageview.image = [[UIImage alloc] initWithData:[[self.docData objectForKey:@"Foto"]getData]];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




- (IBAction)contactarAction:(id)sender {
   }

@end
