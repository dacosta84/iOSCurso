//
//  LoginViewController.m
//  Tarea4
//
//  Created by David on 7/29/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "LoginViewController.h"
#import <Parse/Parse.h>
#import "SigninViewController.h"
#import "ForgotpassViewController.h"
#import "OptionsTabBarController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)loginbutton:(id)sender {
    [PFUser logInWithUsernameInBackground:self.usertextfield.text password:self.passwordtextfield.text
                                    block:^(PFUser *user, NSError *error) {
                                        if (user) {
                                            OptionsTabBarController *newView = [self.storyboard instantiateViewControllerWithIdentifier:@"OptionsTabBarController"];
                                            [self.navigationController pushViewController:newView animated:YES];
                                            
                                            // Do stuff after successful login.
                                        } else {
                                            
                                            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Usuario o contraseña incorrecta" delegate:nil cancelButtonTitle:@"Aceptar" otherButtonTitles:nil, nil];
                                            [errorAlertView show];
                                            
                                            // The login failed. Check error to see why.
                                        }
                                    }];
    
}

- (IBAction)signinaction:(id)sender {
    SigninViewController *registerViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"SigninViewController"];
    [self.navigationController pushViewController:registerViewController animated:YES];
}

- (IBAction)forgotpasswordaction:(id)sender {
    ForgotpassViewController *newView = [self.storyboard instantiateViewControllerWithIdentifier:@"ForgotpassViewController"];
    [self.navigationController pushViewController:newView animated:YES];}



@end
