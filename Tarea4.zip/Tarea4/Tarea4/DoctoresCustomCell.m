//
//  DoctoresCustomCell.m
//  Tarea4
//
//  Created by David on 8/21/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "DoctoresCustomCell.h"

@implementation DoctoresCustomCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
