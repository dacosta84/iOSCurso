//
//  SucursalCustomCell.h
//  Tarea4
//
//  Created by David on 8/21/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SucursalCustomCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *sucursalimageview;
@property (weak, nonatomic) IBOutlet UILabel *sucnamelabel;
@property (weak, nonatomic) IBOutlet UILabel *sucublabel;
@property (weak, nonatomic) IBOutlet UILabel *suctellabel;

@end
