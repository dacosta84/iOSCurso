//
//  SigninViewController.m
//  Tarea4
//
//  Created by David on 7/29/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import "SigninViewController.h"
#import <Parse/Parse.h>

@interface SigninViewController ()

@end

@implementation SigninViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)confirmaraction:(id)sender {
    [self doRegistration];
}

-(void)doRegistration{
    BOOL passwordAreEqual = [self.passwordtextfield.text isEqualToString:self.confirmpasstextfield.text];
    BOOL textFieldDontHaveSpacesInWhite = [self validateAllSpacesInWhiteInTextFields];
    if (passwordAreEqual && textFieldDontHaveSpacesInWhite) {
        //        LISTO PARA TRABAJAR CON PARSE
        [self registerWithParse];
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"ERROR" message:@"Verifique los campos ingresados" delegate:nil cancelButtonTitle:@"Aceptar" otherButtonTitles:nil, nil]
        ;
        [alert show];
    }
}

-(void)registerWithParse{
    PFUser *user = [PFUser user];
    user.username = self.emailtextfield.text;
    user.password = self.passwordtextfield.text;
    user.email = self.emailtextfield.text;
    user[@"name"] = self.nombretextfield.text;
    [user signUpInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        if (!error) {
            [self.navigationController popViewControllerAnimated:YES];
        } else {
            NSString *errorString = [error userInfo][@"error"];
            NSLog(@"ERROR %@",errorString);
        }
    }];
}

-(BOOL)validateWhiteSpaces:(NSString*)textToEvaluate{
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [textToEvaluate stringByTrimmingCharactersInSet:whitespace];
    if ([trimmed length] == 0) {
        // Text was empty or only whitespace.
        return NO;
    }
    else{
        return YES;
    }
}

-(BOOL)validateAllSpacesInWhiteInTextFields{
    BOOL nameValidation = [self validateWhiteSpaces:self.nombretextfield.text];
    BOOL emailValidation = [self validateWhiteSpaces:self.emailtextfield.text];
    BOOL password1 = [self validateWhiteSpaces:self.passwordtextfield.text];
    BOOL password2 = [self validateWhiteSpaces:self.confirmpasstextfield.text];
    BOOL empresa = [self validateWhiteSpaces:self.empresatextfield.text];
    BOOL cedula = [self validateWhiteSpaces:self.cedulatextfield.text];
    BOOL tiposangre = [self validateWhiteSpaces:self.tiposangretextfield.text];
    
    
    if (nameValidation && emailValidation && password1 && password2 && empresa && cedula && tiposangre) {
        return YES;
    }
    else{
        return NO;
    }
}

@end
