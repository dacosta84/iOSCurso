//
//  SigninViewController.h
//  Tarea4
//
//  Created by David on 7/29/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SigninViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *nombretextfield;
@property (weak, nonatomic) IBOutlet UITextField *cedulatextfield;
@property (weak, nonatomic) IBOutlet UITextField *emailtextfield;
@property (weak, nonatomic) IBOutlet UITextField *empresatextfield;
@property (weak, nonatomic) IBOutlet UITextField *tiposangretextfield;
- (IBAction)confirmaraction:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *passwordtextfield;
@property (weak, nonatomic) IBOutlet UITextField *confirmpasstextfield;

@end
