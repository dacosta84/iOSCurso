//
//  ViewController.h
//  Tarea 4
//
//  Created by David on 7/15/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *textlabel;
@end

@interface UILabel (dynamicSizeMe)
-(float) resizeToFit;
-(float) expectedHeight;

@end

