//
//  AppDelegate.h
//  Tarea 4
//
//  Created by David on 7/15/15.
//  Copyright (c) 2015 Diego. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

